HeyHood founder documentation pack — 8 October 2026

Start with HeyHood-India-Investor-Brief.pdf (11 pages).
Then read HeyHood-Product-Strategy-India.pdf (28 pages).

The matching .md files are editable source documents.
The .html files are self-contained browser-readable versions with embedded fonts/logo.
The PDFs have searchable text, outline bookmarks and source links.

Scope: problem, provider/seeker framework, community-context moat, unmet-demand sourcing,
blue-collar subscriptions, chat-first UX, longer-term partner household commerce,
Indian competitors, investor objections, pricing/market scenarios and evidence roadmap.

Competitor observations are sourced vendor descriptions, not logged-in audits.
Product status distinguishes live implementation from demo data and future work.
Revenue examples are assumptions, not achieved traction or market estimates.
No new integrations, outreach, invitations, OTP or application features were deployed
by producing this pack. The engineering handoff lives in the repository docs folder.
